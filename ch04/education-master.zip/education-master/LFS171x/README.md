## LFS171x: Blockchain for Business - An Introduction to Hyperledger Technologies

The source code and documentation in this directory is for the Introduction to Hyperledger Technologies course on edX. This course is a primer to blockchain and distributed ledger technologies. Learn how to start building blockchain applications with Hyperledger frameworks.

The course is free and open to the public and you can find it and sign up here: 

(https://www.edx.org/course/blockchain-business-introduction-linuxfoundationx-lfs171x)